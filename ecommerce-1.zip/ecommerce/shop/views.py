from django.shortcuts import render
from .models import Product, Order


def home(request):
    products = Product.objects.all()
    return render(request, 'shop/home.html', {'products': products})
def product_detail(request, id):
    product = Product.objects.get(id=id)
    return render(request, 'shop/product_detail.html', {'product': product})
def order_tracking(request):

    orders = []

    if request.method == 'POST':
        email = request.POST.get('email')
        orders = Order.objects.filter(email=email).order_by('-created_at')

    return render(
        request,
        'shop/order_tracking.html',
        {'orders': orders}
    )