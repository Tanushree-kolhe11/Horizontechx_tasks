from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from shop.models import Product, Order, OrderItem

@login_required(login_url='/accounts/login/')
def checkout(request):

    cart = request.session.get('cart', {})

    products = []
    grand_total = 0

    for product_id, quantity in cart.items():

        product = Product.objects.get(id=product_id)

        total = product.price * quantity
        grand_total += total

        products.append({
            'product': product,
            'quantity': quantity,
            'total': total
        })

    if request.method == 'POST':

        name = request.POST.get('name')
        email = request.POST.get('email')
        address = request.POST.get('address')

        order = Order.objects.create(
            name=name,
            email=email,
            address=address,
            total_amount=grand_total
        )

        for product_id, quantity in cart.items():

            product = Product.objects.get(id=product_id)

            OrderItem.objects.create(
                order=order,
                product=product,
                quantity=quantity,
                price=product.price
            )

            product.stock -= quantity
            product.save()

        request.session['cart'] = {}

        return redirect('order_success')

    return render(
        request,
        'checkout/checkout.html',
        {
            'products': products,
            'grand_total': grand_total
        }
    )


def order_success(request):
    return render(request, 'checkout/success.html')