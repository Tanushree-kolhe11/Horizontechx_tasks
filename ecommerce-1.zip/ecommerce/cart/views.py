from django.shortcuts import redirect, render
from shop.models import Product
from django.shortcuts import redirect, render

def add_to_cart(request, product_id):
    product = Product.objects.get(id=product_id)

    cart = request.session.get('cart', {})

    if str(product_id) in cart:
        cart[str(product_id)] += 1
    else:
        cart[str(product_id)] = 1

    request.session['cart'] = cart

    return redirect('cart')


def cart_view(request):
    cart = request.session.get('cart', {})

    products = []
    grand_total = 0

    for product_id, quantity in cart.items():
        product = Product.objects.get(id=product_id)

        total = product.price * quantity
        grand_total += total

        products.append({
            'product': product,
            'quantity': quantity,
            'total': total
        })

    return render(
        request,
        'cart/cart.html',
        {
            'products': products,
            'grand_total': grand_total
        }
    )

def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})

    product_id = str(product_id)

    if product_id in cart:
        del cart[product_id]

    request.session['cart'] = cart

    return redirect('cart')
def increase_quantity(request, product_id):
    cart = request.session.get('cart', {})

    product_id = str(product_id)

    if product_id in cart:

        product = Product.objects.get(id=product_id)

        if cart[product_id] < product.stock:
            cart[product_id] += 1

    request.session['cart'] = cart

    return redirect('cart')


def decrease_quantity(request, product_id):
    cart = request.session.get('cart', {})

    product_id = str(product_id)

    if product_id in cart:
        if cart[product_id] > 1:
            cart[product_id] -= 1
        else:
            del cart[product_id]

    request.session['cart'] = cart

    return redirect('cart')